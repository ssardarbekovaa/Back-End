const express = require("express");
const app = express();
const port = 3000;

app.set('view engine', 'ejs');

app.get("/", function (req, res){
 res.render("index.ejs")
});

app.use(express.static('public'));
app.use(express.static('public/css'));
app.use(express.static('public/images'));
app.use(express.static('public/js'));

app.use("/", require("./routes/root.js"));
app.use("/tops", require("./routes/tops.js"));
app.use("/login", require("./routes/login.js"));
app.use("/userprofile", require("./routes/userprofile.js"));
app.use("/adminprofile", require("./routes/adminprofile.js"));
app.use('/register', require("./routes/register.js"));


 app.listen(port, () =>
    console.log(`App listening at http://localhost:${port}`)
);
