const express = require("express");
const router = express.Router();
router
    .route("/")
    .get((req, res) => res.sendFile('/Users/HP/WebstormProjects/untitled4/main/register.html'))
    .post((req, res) => res.sendFile('/Users/HP/WebstormProjects/untitled4/main/register.html'));
module.exports = router;
