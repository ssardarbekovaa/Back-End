const express = require("express");
const app = express();
const router = express.Router();
router
    .route("/")
    .get((req, res) => res.sendFile('/Users/HP/WebstormProjects/untitled4/main/index.html'));
module.exports = router;
