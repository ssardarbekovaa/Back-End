const express = require("express");
const router = express.Router();

router
    .route("/")
    .get((req, res) => res.sendFile('/Users/HP/WebstormProjects/untitled4/main/login.html'))
    .post((req, res) => res.sendFile('/Users/HP/WebstormProjects/untitled4/main/login.html'));
module.exports = router;
